// Apenas para estudo!

// import { ref } from 'vue'
// import { registerUser } from '@/services/auth'

// export function useAuth() {
//   const form = ref({
//     name: '',
//     email: '',
//     password: '',
//     confirmPassword: ''
//   })

//   const register = async () => {
//     try {
//       await registerUser(form.value)
//       return true
//     } catch (error) {
//       return false
//     }
//   }

//   return { form, register }
// } 