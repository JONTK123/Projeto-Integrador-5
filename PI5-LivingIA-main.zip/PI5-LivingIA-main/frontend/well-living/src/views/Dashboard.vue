<template>
  <div style="width: 100%; height: 100vh;">
  <iframe
      src="http://localhost:5000/dash/"
      width="100%"
      height="100%"
      style="border: none;"
      title="Dashboard Imobiliário"></iframe>
      </div>
</template>

<script>
export default {
  name: 'Dashboard',
};
</script>